employeeDrct.controller('employeeCtrl',['$scope','$http','employeesService',employeeCtrl]);

function employeeCtrl($scope, $http,employeesService){
	var vm = this;
	vm.employees = [];
	vm.employee = {
			name : "",
			email : "",
			dateOfBirth : "",
			department : "",
			gender : "",
			age : ""
	};
	vm.dateOptions = {
			dateFormat: 'mm-dd-yy',
		    maxDate: new Date(),
		    startingDay: 1
		  };
	vm.open2 = open2;
	vm.isEdit = false;
	vm.responce = {};
	vm.ageCalc = ageCalc;
	vm.getData = getData;
	vm.close = close;
	
	vm.addEmployee = addEmployee;
	vm.editEmployee = editEmployee;
	vm.deletetEmployee = deletetEmployee;
	vm.updatetEmployee = updatetEmployee;
	vm.popup2 = {opened:false}
	function close(){
		vm.responce = {};
	}
	function ageCalc(){
		var date = new Date();
		vm.employee.age = date.getFullYear() - vm.employee.dateOfBirth.getFullYear();
	}
	function open2() {
	    vm.popup2.opened = true;
	  };
	function getData(){
		 employeesService.getData().then(function(data){
			 vm.employees = data.data;
		 });
	}
	function addEmployee(){
		vm.responce = employeesService.addEmployee(vm.employee);
		vm.employee = {};
		vm.getData();
	}
	function editEmployee(employee){
		vm.employee = angular.copy(employee);
		vm.employee.dateOfBirth = new Date(employee.dateOfBirth);
		vm.isEdit = true;
	}
	function deletetEmployee(employee){
		vm.responce = employeesService.deleteEmployee(employee);
		vm.getData();
	}
	function updatetEmployee(){
		vm.responce = employeesService.updateEmployee(vm.employee);
		vm.employee = {};
		vm.isEdit = false;
		vm.getData();
	}
	vm.getData();
}