employeeDrct.factory('employeesService',['$http','$q',employeesService]);

function employeesService($http, $q){
	var response= {};
	var employees = [];
	var employeeService = {
			getData : getData,
			addEmployee : addEmployee,
			updateEmployee : updateEmployee,
			deleteEmployee : deleteEmployee
	}
	function getData(){
		var defer = $q.defer();
		$http.get('/getEmployees').then(function(data){
			defer.resolve(data);
		})
		return defer.promise;
	}
	function addEmployee(employee){
		$http.post('/addEmployee',employee).then(function(data){
			response.Msg = "Employee added successfully";
			response.type = "success";
		},function(err){
			response.Msg = "One or more details are duplicate : " + err.data.errmsg;
			response.type = "danger";
		})
		return response;
	}
	function updateEmployee(employee){
		$http.post('/updateEmployee',employee).then(function(data){
			response.Msg = "Employee updated successfully";
			response.type = "success";
		},function(err){
			response.Msg = "One or more details are duplicate : " + err.data.errmsg;
			response.type = "danger";
		})
		return response;
	}
	function deleteEmployee(employee){
		$http.delete('/deleteEmployee/' + employee._id).then(function(data){
			response.Msg = "Employee deleted";
			response.type = "warning";
		})
		return response;
	}
	
	return employeeService;
}