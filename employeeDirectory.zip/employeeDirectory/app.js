var express = require('express')
  , path = require('path')
  , bodyParser = require('body-parser')
  , db = require('./db/db')
  , employee = require('./server/route');

var app = express();

var port = process.env.PORT || 8080;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'clintlib')));

app.get('/', employee.defaultPage);

app.post('/addEmployee',employee.add);

app.delete('/deleteEmployee/:empId', employee.delete);

app.post('/updateEmployee', employee.update);

app.get('/getEmployees', employee.getEmployee);


app.listen(port,function(req, res){
	console.log("server is listening to port ", port);
});
