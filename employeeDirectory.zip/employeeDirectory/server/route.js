var express = require('express')
  , mongoose = require('mongoose')
  , Employee = mongoose.model('employee');


exports.defaultPage = function(req,res){
	res.redirect('/index.html');
};

exports.getEmployee = function(req,res){
	Employee.find({},function(err, employees){
		res.send(employees);
	})
};

exports.add = function(req,res){
	var newEmployee = new Employee();
	newEmployee.name = req.body.name;
	newEmployee.email = req.body.email;
	newEmployee.dateOfBirth = req.body.dateOfBirth;
	newEmployee.department = req.body.department;
	newEmployee.gender = req.body.gender;
	newEmployee.age = req.body.age;
	
	newEmployee.save(function(err,savedEmployee){
		if(err){
			res.status(500).send(err);
		}else{
			res.end();
		}
	})
};

exports.update = function(req,res){
	Employee.findOne({
		_id : req.body._id
		}, function(err, data){
			data.name = req.body.name;
			data.email = req.body.email;
			data.dateOfBirth = req.body.dateOfBirth;
			data.department = req.body.department;
			data.gender = req.body.gender;
			data.age = req.body.age;
			data.save(function(err,savedEmployee){
				if(err){
					res.status(500).send(err);
				}else{
					res.end();
				}
			});
		})
};

exports.delete = function(req, res){
	Employee.remove({
		_id : req.params.empId
	},function(err, data){
		res.end();
	});
}