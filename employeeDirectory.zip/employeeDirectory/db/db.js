var mongoose = require('mongoose');
var dbURI = 'mongodb://localhost/test';

mongoose.connect(dbURI);

mongoose.connection.on('connected',function(){
	console.log("Mongoose connected to ", dbURI);
});
mongoose.connection.on('error',function(err){
	console.log("Error occured during connection ", err);
});
mongoose.connection.on('disconnected', function(){
	console.log("DB disconnected");
});

var employeeSchema = new mongoose.Schema({
	name: {type: String, unique:true, required:true},
	email:{type:String, unique:true, required:true},
	dateOfBirth: {type: Date, required:true},
	department: {type: String, required:true},
	gender: {type:String, required:true},
	age: {type:String, required:true}
});

mongoose.model('employee', employeeSchema, 'employees');